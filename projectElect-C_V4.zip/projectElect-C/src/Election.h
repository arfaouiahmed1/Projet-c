#ifndef ELECTION_H_INCLUDED
#define ELECTION_H_INCLUDED
#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>

typedef struct
{
    int jour;
    int mois;
    int annee;
}Date;

typedef struct
{
    int id;
    char Name[20];
    int nb_habitant;
    int nb_conseiller;
    char municipalite[20];
    Date DDDC;
    Date DFDC;
    Date DDV;
    Date DFV;
}Election;

int ajouterElect(Election E);
int modifierElect(int id, Election N);
int supprimerElect(int id);
Election chercherElect(int id);
void afficheElect(GtkWidget *liste);
void viderElect(GtkWidget *liste);


#endif
