#include "Election.h"
#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>


enum
{
	ID,
	NOM,
	NBRHABITANT,
	NBRCONSEILLER,
	MUNICIPALITE,
	DDDC,
	DFDC,
	DDV,
	DFV,
	COLUMNS
};

int ajouterElect(Election E)
{
    if(E.nb_habitant<=5000)
        E.nb_conseiller=10;
    else if(E.nb_habitant>5000 && E.nb_habitant<=10000)
        E.nb_conseiller=12;
    else if(E.nb_habitant>10000 && E.nb_habitant<=25000)
        E.nb_conseiller=16;
    else if(E.nb_habitant>25000 && E.nb_habitant<=50000)
        E.nb_conseiller=22;
    else if(E.nb_habitant>50000 && E.nb_habitant<=100000)
        E.nb_conseiller=30;
    else if(E.nb_habitant>100000 && E.nb_habitant<=500000)
        E.nb_conseiller=40;
    else if(E.nb_habitant>500000)
        E.nb_conseiller=60;
    FILE * f=fopen("ElecList.txt", "a+");
    if(f!=NULL)
    {
        fprintf(f,"%d  %s  %d  %d  %s  %d %d %d  %d %d %d  %d %d %d  %d %d %d \n",E.id,E.Name,E.nb_habitant,E.nb_conseiller,E.municipalite,E.DDDC.jour,E.DDDC.mois,E.DDDC.annee,E.DFDC.jour,E.DFDC.mois,E.DFDC.annee,E.DDV.jour,E.DDV.mois,E.DDV.annee,E.DFV.jour,E.DFV.mois,E.DFV.annee);
        fclose(f);
        return 1;
    }
    else return 0;
}

int modifierElect(int id, Election N)
{
    Election E;
    if(N.nb_habitant<=5000)
        N.nb_conseiller=10;
    else if(N.nb_habitant>5000 && N.nb_habitant<=10000)
        N.nb_conseiller=12;
    else if(N.nb_habitant>10000 && N.nb_habitant<=25000)
        N.nb_conseiller=16;
    else if(N.nb_habitant>25000 && N.nb_habitant<=50000)
        N.nb_conseiller=22;
    else if(N.nb_habitant>50000 && N.nb_habitant<=100000)
        N.nb_conseiller=30;
    else if(N.nb_habitant>100000 && N.nb_habitant<=500000)
        N.nb_conseiller=40;
    else if(N.nb_habitant>500000)
        N.nb_conseiller=60;
    FILE * f1 =fopen("ElecList.txt", "r");
    FILE * f2 =fopen("aux.txt", "w");
    if(f1==NULL || f2==NULL)
return 0;
else
    {
while(fscanf(f1,"%d  %s  %d  %d  %s  %d %d %d  %d %d %d  %d %d %d  %d %d %d \n",&E.id,E.Name,&E.nb_habitant,&E.nb_conseiller,E.municipalite,&E.DDDC.jour,&E.DDDC.mois,&E.DDDC.annee,&E.DFDC.jour,&E.DFDC.mois,&E.DFDC.annee,&E.DDV.jour,&E.DDV.mois,&E.DDV.annee,&E.DFV.jour,&E.DFV.mois,&E.DFV.annee)!=EOF)
{
if(E.id!=id)
        fprintf(f2,"%d  %s  %d  %d  %s  %d %d %d  %d %d %d  %d %d %d  %d %d %d \n",E.id,E.Name,E.nb_habitant,E.nb_conseiller,E.municipalite,E.DDDC.jour,E.DDDC.mois,E.DDDC.annee,E.DFDC.jour,E.DFDC.mois,E.DFDC.annee,E.DDV.jour,E.DDV.mois,E.DDV.annee,E.DFV.jour,E.DFV.mois,E.DFV.annee);
else

  fprintf(f2,"%d  %s  %d  %d  %s  %d %d %d  %d %d %d  %d %d %d  %d %d %d \n",N.id,N.Name,N.nb_habitant,N.nb_conseiller,N.municipalite,N.DDDC.jour,N.DDDC.mois,N.DDDC.annee,N.DFDC.jour,N.DFDC.mois,N.DFDC.annee,N.DDV.jour,N.DDV.mois,N.DDV.annee,N.DFV.jour,N.DFV.mois,N.DFV.annee);

}
        fclose(f1);
        fclose(f2);
remove("ElecList.txt");
rename("aux.txt", "ElecList.txt");
        return 1;
    }
}


int supprimerElect(int id)
{
Election E;
    FILE * f1 =fopen("ElecList.txt", "r");
    FILE * f2 =fopen("aux.txt", "w");
    if(f1==NULL || f2==NULL)
return 0;
else
    {
while(fscanf(f1,"%d  %s  %d  %d  %s  %d %d %d  %d %d %d  %d %d %d  %d %d %d \n",&E.id,E.Name,&E.nb_habitant,&E.nb_conseiller,E.municipalite,&E.DDDC.jour,&E.DDDC.mois,&E.DDDC.annee,&E.DFDC.jour,&E.DFDC.mois,&E.DFDC.annee,&E.DDV.jour,&E.DDV.mois,&E.DDV.annee,&E.DFV.jour,&E.DFV.mois,&E.DFV.annee)!=EOF)
{
if(E.id!=id)
        fprintf(f2,"%d  %s  %d  %d  %s  %d %d %d  %d %d %d  %d %d %d  %d %d %d \n",E.id,E.Name,E.nb_habitant,E.nb_conseiller,E.municipalite,E.DDDC.jour,E.DDDC.mois,E.DDDC.annee,E.DFDC.jour,E.DFDC.mois,E.DFDC.annee,E.DDV.jour,E.DDV.mois,E.DDV.annee,E.DFV.jour,E.DFV.mois,E.DFV.annee);

}
        fclose(f1);
        fclose(f2);
remove("ElecList.txt");
rename("aux.txt", "ElecList.txt");
        return 1;
    }
}


Election chercherElect(int id)
{
Election E;
int tr=0;
    FILE * f=fopen("ElecList.txt", "r");
 if(f!=NULL )
    {
    while(fscanf(f,"%d  %s  %d  %d  %s  %d %d %d  %d %d %d  %d %d %d  %d %d %d \n",&E.id,E.Name,&E.nb_habitant,&E.nb_conseiller,E.municipalite,&E.DDDC.jour,&E.DDDC.mois,&E.DDDC.annee,&E.DFDC.jour,&E.DFDC.mois,&E.DFDC.annee,&E.DDV.jour,&E.DDV.mois,&E.DDV.annee,&E.DFV.jour,&E.DFV.mois,&E.DFV.annee)!=EOF && tr==0)
        {
            if(id==E.id)
            tr=1;
        }
    }
if(tr==0)
E.id=-1;
return E;

}

void afficheElect(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	char id[20];
	char Nom[20];
	char NbrHabitant[20];
	char NbrConseiller[20];
        char municipalite[20];
	char  dddc[20];
	char  dfdc[20];
        char  ddv[20];
	char  dfv[20];

	Election E;

	store=NULL;
	FILE *f;


	store=gtk_tree_view_get_model(liste);
	if(store==NULL)
	{
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ID",renderer, "text",ID,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column =gtk_tree_view_column_new_with_attributes("Nom",renderer,"text",NOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("NbrHabitant",renderer, "text", NBRHABITANT,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("NbrConseiller",renderer, "text",NBRCONSEILLER,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("municipalite",renderer, "text",MUNICIPALITE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("DDDC",renderer, "text",DDDC,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("DFDC",renderer, "text",DFDC,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("DDV",renderer, "text",DDV,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("DFV",renderer, "text",DFV,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	}



	store=gtk_list_store_new (COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
	f=fopen("ElecList.txt","r");
	if(f==NULL)
	{
		return;
	}
	else
	{
		f=fopen("ElecList.txt","r");
	 	       while(fscanf(f,"%d  %s  %d  %d  %s  %d %d %d  %d %d %d  %d %d %d  %d %d %d \n",&E.id,E.Name,&E.nb_habitant,&E.nb_conseiller,E.municipalite,&E.DDDC.jour,&E.DDDC.mois,&E.DDDC.annee,&E.DFDC.jour,&E.DFDC.mois,&E.DFDC.annee,&E.DDV.jour,&E.DDV.mois,&E.DDV.annee,&E.DFV.jour,&E.DFV.mois,&E.DFV.annee)!=EOF)	          						  
		{
			sprintf(ID,"%d",E.id);
			strcpy(Nom,E.Name);
			sprintf(NbrHabitant,"%d",E.nb_habitant);
			sprintf(NbrConseiller,"%d",E.nb_conseiller);
			strcpy(municipalite,E.municipalite);
			sprintf(dddc," %d/%d/%d ",E.DDDC.jour ,E.DDDC.mois ,E.DDDC.annee);
			sprintf(dfdc," %d/%d/%d ",E.DFDC.jour ,E.DFDC.mois ,E.DFDC.annee);
			sprintf(ddv," %d/%d/%d ",E.DDV.jour ,E.DDV.mois ,E.DDV.annee);
			sprintf(dfv," %d/%d/%d ",E.DFV.jour ,E.DFV.mois ,E.DFV.annee);

			gtk_list_store_append (store, &iter);
       
			gtk_list_store_set (store, &iter, ID, id, NOM, Nom, NBRHABITANT, NbrHabitant, NBRCONSEILLER, NbrConseiller, MUNICIPALITE ,municipalite , DDDC, dddc, DFDC, dfdc, DDV, ddv, DFV, dfv, -1);
                 }
		fclose(f);
		gtk_tree_view_set_model (GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
		g_object_unref (store);
	}
}


void viderElect(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	char id[20];
	char Nom[20];
	char NbrHabitant[20];
	char NbrConseiller[20];
        char municipalite[20];
	char  dddc[20];
	char  dfdc[20];
        char  ddv[20];
	char  dfv[20];

	Election E;

	store=NULL;
	FILE *f;


	store=gtk_tree_view_get_model(liste);
	if(store==NULL)
	{
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ID",renderer, "text",ID,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column =gtk_tree_view_column_new_with_attributes("Nom",renderer,"text",NOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("NbrHabitant",renderer, "text", NBRHABITANT,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
 
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("NbrConseiller",renderer, "text",NBRCONSEILLER,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("municipalite",renderer, "text",MUNICIPALITE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("DDDC",renderer, "text",DDDC,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("DFDC",renderer, "text",DFDC,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("DDV",renderer, "text",DDV,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("DFV",renderer, "text",DFV,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
	}

	store=gtk_list_store_new (COLUMNS, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
	gtk_list_store_append (store, &iter);
	gtk_tree_view_set_model(GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));

}















