#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "Election.h"


void
on_SB_button_DCNX_AM_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonElec_clicked                  (GtkWidget       *button,
                                        gpointer         user_data)
{
  GtkWidget *Admin_Win;
  GtkWidget *Election_Admin;
  Admin_Win = lookup_widget(button, "Admin_Win");
  gtk_widget_destroy(Admin_Win);
  Election_Admin = create_Election_Admin();
  gtk_widget_show(Election_Admin);
}


void
on_buttonUtil_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonListElec_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonBurDeVote_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonReclam_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonStat_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonLogout_ElectAd_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_buttonActl_ElectAd_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *Election_Admin,*w1;
	GtkWidget *treeview1;

	w1=lookup_widget(objet,"Election_Admin");
	Election_Admin=create_Election_Admin();
	gtk_widget_show(Election_Admin);
	gtk_widget_hide(w1);
	treeview1=lookup_widget(Election_Admin,"treeview_ElectAd");
	viderElect(treeview1);
	afficheElect(treeview1);

}


void
on_buttonMod_ElectAd_clicked           (GtkWidget       *button,
                                        gpointer         user_data)
{
  GtkWidget *Modif_Elect;
  GtkWidget *Election_Admin;
  Election_Admin = lookup_widget(button, "Election_Admin");
  gtk_widget_destroy(Election_Admin);
  Modif_Elect = create_Modif_Elect();
  gtk_widget_show(Modif_Elect);
}


void
on_buttonSupp_ElectAd_clicked          (GtkWidget       *button,
                                        gpointer         user_data)
{

}


void
on_buttonRet_ElectAd_clicked           (GtkWidget       *button,
                                        gpointer         user_data)
{
  GtkWidget *Admin_Win;
  GtkWidget *Election_Admin;
  Election_Admin = lookup_widget(button, "Election_Admin");
  gtk_widget_destroy(Election_Admin);
  Admin_Win = create_Admin_Win();
  gtk_widget_show(Admin_Win);
}


void
on_buttonSerch_ElectAd_clicked         (GtkWidget       *button,
                                        gpointer         user_data)
{

}


void
on_buttonAjt_ElectAd_clicked           (GtkWidget       *button,
                                        gpointer         user_data)
{
  GtkWidget *Ajt_Elect;
  GtkWidget *Election_Admin;
  Election_Admin = lookup_widget(button, "Election_Admin");
  gtk_widget_destroy(Election_Admin);
  Ajt_Elect = create_Ajt_Elect();
  gtk_widget_show(Ajt_Elect);
}


void
on_buttonAjt_ElectAjt_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget *input1 ;
  GtkWidget *input2 ;
  GtkWidget *input3 ;
  GtkWidget *combobox1 ;
  GtkWidget *spin1 ;
  GtkWidget *spin2 ;
  GtkWidget *spin3 ;
  GtkWidget *spin4 ;
  GtkWidget *spin5 ;
  GtkWidget *spin6 ;
  GtkWidget *spin7 ;
  GtkWidget *spin8 ;
  GtkWidget *spin9 ;
  GtkWidget *spin10 ;
  GtkWidget *spin11 ;
  GtkWidget *spin12 ;
  Election E ;
  int i ;
  
  input1=lookup_widget(objet_graphique,"entry_ID_ElectAjt");
  input2=lookup_widget(objet_graphique,"entry_Nom_ElectAjt");
  input3=lookup_widget(objet_graphique,"entry_NbrHab_ElectAjt");
  combobox1=lookup_widget(objet_graphique,"combobox_ElectAjt");
  spin1=lookup_widget(objet_graphique,"spinbutton1_ElectAjt");
  spin2=lookup_widget(objet_graphique,"spinbutton2_ElectAjt");
  spin3=lookup_widget(objet_graphique,"spinbutton3_ElectAjt");
  spin4=lookup_widget(objet_graphique,"spinbutton4_ElectAjt");
  spin5=lookup_widget(objet_graphique,"spinbutton5_ElectAjt");
  spin6=lookup_widget(objet_graphique,"spinbutton6_ElectAjt");
  spin7=lookup_widget(objet_graphique,"spinbutton7_ElectAjt");
  spin8=lookup_widget(objet_graphique,"spinbutton8_ElectAjt");
  spin9=lookup_widget(objet_graphique,"spinbutton9_ElectAjt");
  spin10=lookup_widget(objet_graphique,"spinbutton10_ElectAjt");
  spin11=lookup_widget(objet_graphique,"spinbutton11_ElectAjt");
  spin12=lookup_widget(objet_graphique,"spinbutton12_ElectAjt");

  E.id=atoi(gtk_entry_get_text(GTK_ENTRY(input1)));
  strcpy(E.Name,gtk_entry_get_text(GTK_ENTRY(input2))); 
  E.nb_habitant=atoi(gtk_entry_get_text(GTK_ENTRY(input3)));
  strcpy(E.municipalite,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
  E.DDDC.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin1));
  E.DDDC.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin2));
  E.DDDC.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin3));
  E.DFDC.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin4));
  E.DFDC.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin5));
  E.DFDC.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin6));
  E.DDV.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin7));
  E.DDV.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin8));
  E.DDV.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin9));
  E.DFV.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin10));
  E.DFV.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin11));
  E.DFV.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin12));
  i=ajouterElect(E);
  if (i==1)
  {
   GtkWidget *Ajt_Elect;
   GtkWidget *Election_Admin;
   Ajt_Elect = lookup_widget(objet_graphique, "Ajt_Elect");
   gtk_widget_destroy(Ajt_Elect);
   Election_Admin = create_Election_Admin();
   gtk_widget_show(Election_Admin);
  }
}


void
on_buttonAnl_ElectAjt_clicked          (GtkWidget       *button,
                                        gpointer         user_data)
{
  GtkWidget *Ajt_Elect;
  GtkWidget *Election_Admin;
  Ajt_Elect = lookup_widget(button, "Ajt_Elect");
  gtk_widget_destroy(Ajt_Elect);
  Election_Admin = create_Election_Admin();
  gtk_widget_show(Election_Admin);
}


void
on_buttonModif_ElectModif_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
  GtkWidget *input1 ;
  GtkWidget *input2 ;
  GtkWidget *input3 ;
  GtkWidget *combobox1 ;
  GtkWidget *spin1 ;
  GtkWidget *spin2 ;
  GtkWidget *spin3 ;
  GtkWidget *spin4 ;
  GtkWidget *spin5 ;
  GtkWidget *spin6 ;
  GtkWidget *spin7 ;
  GtkWidget *spin8 ;
  GtkWidget *spin9 ;
  GtkWidget *spin10 ;
  GtkWidget *spin11 ;
  GtkWidget *spin12 ;
  Election E ;
  int i ;
  
  input1=lookup_widget(objet_graphique,"entry_ID_ElectModif");
  input2=lookup_widget(objet_graphique,"entry_Nom_ElectModif");
  input3=lookup_widget(objet_graphique,"entry_NbrHab_ElectModif");
  combobox1=lookup_widget(objet_graphique,"combobox_ElectModif");
  spin1=lookup_widget(objet_graphique,"spinbutton1_ElectModif");
  spin2=lookup_widget(objet_graphique,"spinbutton2_ElectModif");
  spin3=lookup_widget(objet_graphique,"spinbutton3_ElectModif");
  spin4=lookup_widget(objet_graphique,"spinbutton4_ElectModif");
  spin5=lookup_widget(objet_graphique,"spinbutton5_ElectModif");
  spin6=lookup_widget(objet_graphique,"spinbutton6_ElectModif");
  spin7=lookup_widget(objet_graphique,"spinbutton7_ElectModif");
  spin8=lookup_widget(objet_graphique,"spinbutton8_ElectModif");
  spin9=lookup_widget(objet_graphique,"spinbutton9_ElectModif");
  spin10=lookup_widget(objet_graphique,"spinbutton10_ElectModif");
  spin11=lookup_widget(objet_graphique,"spinbutton11_ElectModif");
  spin12=lookup_widget(objet_graphique,"spinbutton12_ElectModif");

  E.id=atoi(gtk_entry_get_text(GTK_ENTRY(input1)));
  strcpy(E.Name,gtk_entry_get_text(GTK_ENTRY(input2))); 
  E.nb_habitant=atoi(gtk_entry_get_text(GTK_ENTRY(input3)));
  strcpy(E.municipalite,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
  E.DDDC.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin1));
  E.DDDC.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin2));
  E.DDDC.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin3));
  E.DFDC.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin4));
  E.DFDC.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin5));
  E.DFDC.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin6));
  E.DDV.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin7));
  E.DDV.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin8));
  E.DDV.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin9));
  E.DFV.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin10));
  E.DFV.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin11));
  E.DFV.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(spin12));
  i=modifierElect(E.id,E);
  if (i==1)
  {
   GtkWidget *Modif_Elect;
   GtkWidget *Election_Admin;
   Modif_Elect = lookup_widget(objet_graphique, "Modif_Elect");
   gtk_widget_destroy(Modif_Elect);
   Election_Admin = create_Election_Admin();
   gtk_widget_show(Election_Admin);
  }
}


void
on_buttonAnl_ElectModif_clicked        (GtkWidget       *button,
                                        gpointer         user_data)
{
  GtkWidget *Modif_Elect;
  GtkWidget *Election_Admin;
  Modif_Elect = lookup_widget(button, "Modif_Elect");
  gtk_widget_destroy(Modif_Elect);
  Election_Admin = create_Election_Admin();
  gtk_widget_show(Election_Admin);
}


void
on_treeview_ElectAd_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
	GtkTreeIter iter;
	gint *id;
	gchar *nom; 
	gint *nb_habitant;
	gint *nb_conseiller;
 	gchar *municipalite;
	gint *jour1; 
	gint *mois1;
	gint *annee1;
	gint *jour2; 
	gint *mois2;
	gint *annee2;
	gint *jour3; 
	gint *mois3;
	gint *annee3;
	gint *jour4; 
	gint *mois4;
	gint *annee4;
	Election E;                                 
	FILE *f=NULL;

	GtkTreeModel *tree_model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(tree_model,&iter,path))
	{gtk_tree_model_get (GTK_LIST_STORE(tree_model),&iter,0,&id,1,&nom,2,&nb_habitant,3,&nb_conseiller,4,&municipalite,5,&jour1,6,&mois1,7,&annee1,8,&jour2,9,&mois2,10,&annee2,11,&jour3,12,&mois3,13,&annee3,14,&jour4,15,&mois4,16,&annee4,-1);


	E.id=*id;
	strcpy(E.Name,nom);
	E.nb_habitant=*nb_habitant;
	E.nb_conseiller=*nb_conseiller;
	strcpy(E.municipalite,municipalite);
        E.DDDC.jour= *jour1;
        E.DDDC.mois= *mois1;
        E.DDDC.annee= *annee1;
        E.DFDC.jour= *jour2;
        E.DFDC.mois= *mois2;
        E.DFDC.annee= *annee2;
        E.DDV.jour= *jour3;
        E.DDV.mois= *mois3;
        E.DDV.annee= *annee3;
        E.DFV.jour= *jour4;
        E.DFV.mois= *mois4;
        E.DFV.annee= *annee4;

	viderElect(treeview);
	afficheElect(treeview);
}
}

