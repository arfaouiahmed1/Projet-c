#include <gtk/gtk.h>


void
on_SB_button_DCNX_AM_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonElec_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonUtil_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonListElec_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonBurDeVote_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonReclam_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonStat_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonLogout_ElectAd_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonActl_ElectAd_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonMod_ElectAd_clicked           (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonSupp_ElectAd_clicked          (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonRet_ElectAd_clicked           (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonSerch_ElectAd_clicked         (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonAjt_ElectAd_clicked           (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonAjt_ElectAjt_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonAnl_ElectAjt_clicked          (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonModif_ElectModif_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonAnl_ElectModif_clicked        (GtkWidget       *button,
                                        gpointer         user_data);

void
on_treeview_ElectAd_row_activated      (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
